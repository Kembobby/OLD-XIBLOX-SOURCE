<div id="Footer">
    <hr>
    <p class="Legalese">
        <?=$sitename?>, "Online Building Toy", characters, logos, names, and all related indicia are trademarks of <a id="ctl00_rbxFooter_hlRobloxCorporation" href="info/About.aspx"><?=$sitename?> Corporation</a>, ©2009. Patents pending.
        <br><?=$sitename?> Corp. is not affiliated with Lego, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!
        <br>Use of this site signifies your acceptance of the <a id="ctl00_rbxFooter_hlTermsOfService" href="info/TermsOfService.aspx">Terms and Conditions</a>.
        <br><a id="ctl00_rbxFooter_hlPrivacyPolicy" href="info/Privacy.aspx">Privacy Policy</a>
        &nbsp;|&nbsp; <a href="https://web.archive.org/web/20080730072110/mailto:info@roblox.com">Contact Us</a>
        &nbsp;|&nbsp; <a id="ctl00_rbxFooter_hlAboutRoblox" href="info/About.aspx">About Us</a>
        &nbsp;|&nbsp; <a id="ctl00_rbxFooter_HyperLink1" href="info/Jobs.aspx">Jobs</a>
    </p>
</div>