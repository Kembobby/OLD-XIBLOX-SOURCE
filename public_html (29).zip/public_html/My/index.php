<?php
require_once($_SERVER['DOCUMENT_ROOT']."/main/nav.php");
?>
<div id="Body">
<br>
<br>
<br>
<br>
<h2 style="text-align:center">The item you requested does not give access here</h2>
<h4 style="text-align:center">You do NOT have access to this page</h2>
<br>
<br>
<br>
<br>
        </div>
<?php
require_once($_SERVER['DOCUMENT_ROOT']."/main/footer.php");
?>