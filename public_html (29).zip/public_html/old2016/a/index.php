<?php
header("location: /Default.aspx");
?>