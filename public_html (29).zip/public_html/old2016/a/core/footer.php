<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/core/database.php');
?>
<div id="Footer">
					<hr>
					<p class="Legalese">
					    <?=$sitename?>, "A Good Online Toy", characters, logos, names, and all related indicia are trademarks of 
					    <a href="https://corp.roblox.com">ROBLOX Corporation</a>,
					    ©2009. Patents pending.
					    <br>
					    <?=$sitename?> is not affliated with Lego, ROBLOX, MegaBloks, Bionicle, Pokemon, Nintendo, Lincoln Logs, Yu Gi Oh, K'nex, Tinkertoys, Erector Set, or the Pirates of the Caribbean. ARrrr!
					    <br>
					    Use of this site signifies your acceptance of the <a href="/info/TermsOfService.aspx">Terms and Conditions</a>.
					    <br>
					    <a href="/info/Privacy.aspx"><b>Privacy Policy</b></a>
					    &nbsp;|&nbsp; <a href="mailto:">Contact Us</a> 
                        &nbsp;|&nbsp; <a href="/info/About.aspx">About Us</a>
					    &nbsp;|&nbsp; <a href="/">Discord</a>
					    &nbsp;|&nbsp; <a href="/maintenance/status/">Status</a>
					    <br>
						<span>Based off of 2009
					    <br>
					    &nbsp;
				    </span></p>
									</div>