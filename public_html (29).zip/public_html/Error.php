<?php
require($_SERVER["DOCUMENT_ROOT"]."/main/nav.php");
?>
<div id="Body">
					
    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>
    <h2 style="text-align: center">
        The item you requested does not exist</h2>
    <p>
        &nbsp;</p>
    <p>
        &nbsp;</p>

				</div>
<?php
require($_SERVER["DOCUMENT_ROOT"]."/main/footer.php");
?>