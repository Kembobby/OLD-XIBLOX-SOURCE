﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admi/Admi.Master" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Roblox.Website.Admi.Default" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cphRoblox" runat="server">
    <asp:Panel ID="AdminDashboard" Width="960px" runat="server">
        <asp:Panel ID="AdminDashboardSection" GroupingText="Admin Dashboard" runat="server">
            <asp:Panel ID="AdminDashboardPanel" BackColor="LightSteelBlue" runat="server">
                This page intentionally left blank
            </asp:Panel>
        </asp:Panel>
    </asp:Panel>
</asp:Content>
