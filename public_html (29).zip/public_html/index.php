<?php
header("location: /Default.php");
?>